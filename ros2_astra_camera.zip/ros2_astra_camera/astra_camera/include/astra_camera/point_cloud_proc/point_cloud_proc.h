#pragma once

#include "point_cloud_xyz.h"
#include "point_cloud_xyzrgb.h"
