// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ASTRA_CAMERA_MSGS__SRV__GET_INT32_HPP_
#define ASTRA_CAMERA_MSGS__SRV__GET_INT32_HPP_

#include "astra_camera_msgs/srv/detail/get_int32__struct.hpp"
#include "astra_camera_msgs/srv/detail/get_int32__builder.hpp"
#include "astra_camera_msgs/srv/detail/get_int32__traits.hpp"

#endif  // ASTRA_CAMERA_MSGS__SRV__GET_INT32_HPP_
