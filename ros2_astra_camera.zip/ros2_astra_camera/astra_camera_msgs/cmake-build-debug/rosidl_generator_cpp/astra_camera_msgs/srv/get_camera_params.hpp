// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ASTRA_CAMERA_MSGS__SRV__GET_CAMERA_PARAMS_HPP_
#define ASTRA_CAMERA_MSGS__SRV__GET_CAMERA_PARAMS_HPP_

#include "astra_camera_msgs/srv/detail/get_camera_params__struct.hpp"
#include "astra_camera_msgs/srv/detail/get_camera_params__builder.hpp"
#include "astra_camera_msgs/srv/detail/get_camera_params__traits.hpp"

#endif  // ASTRA_CAMERA_MSGS__SRV__GET_CAMERA_PARAMS_HPP_
