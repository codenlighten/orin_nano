// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ASTRA_CAMERA_MSGS__MSG__EXTRINSICS_HPP_
#define ASTRA_CAMERA_MSGS__MSG__EXTRINSICS_HPP_

#include "astra_camera_msgs/msg/detail/extrinsics__struct.hpp"
#include "astra_camera_msgs/msg/detail/extrinsics__builder.hpp"
#include "astra_camera_msgs/msg/detail/extrinsics__traits.hpp"

#endif  // ASTRA_CAMERA_MSGS__MSG__EXTRINSICS_HPP_
