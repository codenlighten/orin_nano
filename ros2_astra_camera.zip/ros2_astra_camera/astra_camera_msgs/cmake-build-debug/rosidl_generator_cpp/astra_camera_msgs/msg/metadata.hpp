// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ASTRA_CAMERA_MSGS__MSG__METADATA_HPP_
#define ASTRA_CAMERA_MSGS__MSG__METADATA_HPP_

#include "astra_camera_msgs/msg/detail/metadata__struct.hpp"
#include "astra_camera_msgs/msg/detail/metadata__builder.hpp"
#include "astra_camera_msgs/msg/detail/metadata__traits.hpp"

#endif  // ASTRA_CAMERA_MSGS__MSG__METADATA_HPP_
