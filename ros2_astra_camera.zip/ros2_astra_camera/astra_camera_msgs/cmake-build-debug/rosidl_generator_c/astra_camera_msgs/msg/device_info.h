// generated from rosidl_generator_c/resource/idl.h.em
// with input from astra_camera_msgs:msg/DeviceInfo.idl
// generated code does not contain a copyright notice

#ifndef ASTRA_CAMERA_MSGS__MSG__DEVICE_INFO_H_
#define ASTRA_CAMERA_MSGS__MSG__DEVICE_INFO_H_

#include "astra_camera_msgs/msg/detail/device_info__struct.h"
#include "astra_camera_msgs/msg/detail/device_info__functions.h"
#include "astra_camera_msgs/msg/detail/device_info__type_support.h"

#endif  // ASTRA_CAMERA_MSGS__MSG__DEVICE_INFO_H_
