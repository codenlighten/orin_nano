// generated from rosidl_generator_c/resource/idl.h.em
// with input from astra_camera_msgs:srv/GetInt32.idl
// generated code does not contain a copyright notice

#ifndef ASTRA_CAMERA_MSGS__SRV__GET_INT32_H_
#define ASTRA_CAMERA_MSGS__SRV__GET_INT32_H_

#include "astra_camera_msgs/srv/detail/get_int32__struct.h"
#include "astra_camera_msgs/srv/detail/get_int32__functions.h"
#include "astra_camera_msgs/srv/detail/get_int32__type_support.h"

#endif  // ASTRA_CAMERA_MSGS__SRV__GET_INT32_H_
