// generated from rosidl_generator_c/resource/idl.h.em
// with input from astra_camera_msgs:srv/GetString.idl
// generated code does not contain a copyright notice

#ifndef ASTRA_CAMERA_MSGS__SRV__GET_STRING_H_
#define ASTRA_CAMERA_MSGS__SRV__GET_STRING_H_

#include "astra_camera_msgs/srv/detail/get_string__struct.h"
#include "astra_camera_msgs/srv/detail/get_string__functions.h"
#include "astra_camera_msgs/srv/detail/get_string__type_support.h"

#endif  // ASTRA_CAMERA_MSGS__SRV__GET_STRING_H_
